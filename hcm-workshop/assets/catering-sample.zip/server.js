const cds = require('@sap/cds');
const express = require('express');

function generateVoucher() {
    const letters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
    const digits = '0123456789';

    let result = '';

    // Генерируем 6 случайных букв
    for (let i = 0; i < 6; i++) {
        result += letters.charAt(Math.floor(Math.random() * letters.length));
    }

    // Генерируем 4 случайных цифры
    for (let i = 0; i < 4; i++) {
        result += digits.charAt(Math.floor(Math.random() * digits.length));
    }

    return result;
}

cds.on('bootstrap', (app) => {
    // Создаём отдельный маршрут
    app.use('/odata/v4/catalog/Voucher', express.json()); // чтобы body был JSON

    app.post('/odata/v4/catalog/Voucher/getVoucher', (req, res) => {
        console.log(req.body);
        if(!req.body.menuItem || !req.body.email){
            res.status(400).send({
                error: {
                    code: "BadRequest",
                    message: "`menuItem` or `email` parameter is missing"
                }
            });
        }
        res.json({ voucherCode: generateVoucher() });
    });

    return app;
});

module.exports = cds.server; // обязательно экспортируем сервер