const cds = require('@sap/cds');

module.exports = cds.service.impl(async function () {
  
    const { Menu } = this.entities;

    this.on('READ', Menu, async (req) => {
        const rows = await cds.tx(req).run(req.query);

        const fullUrl = `https://${req.headers.host}/images`;
        console.log('Current URL:', fullUrl);

        // модифицируем данные после чтения
        return rows.map(each => {
            each.imageURL = `${fullUrl}/${each.imageURL}`;
            return each;
        });
    });
   

});